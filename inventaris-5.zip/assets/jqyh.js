$(document).ready(function(){
		alert('Masa Trial..Silahkan Hubungi Ibenk PIN BB D2222901 WA 085863557740 untuk mendapatkan Full Code');
});
    
	
	