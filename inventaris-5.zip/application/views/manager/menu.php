<ul class="sidebar-menu">

        <li class="header"> <a href="<?php echo base_url()?>index.php/manager">DASHBOARD</a></li>
        
        
       
        
        
        <li class="treeview">
          <a href="<?php echo base_url()?>index.php/manager/karyawan">
            <i class="fa fa-users"></i>
            <span>KARYAWAN</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
         
        </li>
         
         
        <li class="treeview">
          <a href="<?php echo base_url()?>index.php/manager/inventaris">
            <i class="fa fa-laptop"></i>
            <span>INVENTARIS</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
         
        </li>
        <li class="treeview">
          <a href="<?php echo base_url()?>index.php/manager/laporan">
            <i class="fa fa-book"></i>
            <span>LAPORAN</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
         
        </li>
        
        
        
         
               

      
      </ul>
      
      
      
      
      
      
      
      