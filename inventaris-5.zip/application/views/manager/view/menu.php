<ul class="sidebar-menu">

        <li class="header"> <a href="<?php echo base_url()?>index.php/home_admin">DASHBOARD</a></li>
        
        
        <li class="treeview">
          <a href="<?php echo base_url()?>index.php/admin/personil">
            <i class="fa fa-user"></i>
            <span>PERSONIL</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
         
        </li>
        
        
        
         <li class="treeview">
          <a href="<?php echo base_url()?>index.php/admin/user">
            <i class="fa fa-users"></i>
            <span>USER</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
        </li>
      
         <li class="treeview">
          <a href="<?php echo base_url()?>index.php/user/tamu">
            <i class="fa fa-book"></i>
            <span>BUKU TAMMU</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
        </li>


         <li class="treeview">
          <a href="<?php echo base_url()?>index.php/user/grafik">
            <i class="fa fa-book"></i>
            <span>GRAFICK</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
          
        </li>
               

      
      </ul>
      
      
      
      
      
      
      
      