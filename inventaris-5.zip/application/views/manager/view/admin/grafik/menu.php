<div class="box box-primary">
            
           
            <!-- form start -->
    <form class="form" action="<?php echo base_url()?>index.php/user/grafik/grafikcek" method="post" enctype="multipart/form-data">
              <div class="box-body">
                
                <div class="form-group">
                
                  <label for="exampleInputEmail1">Tahun</label>
                <input type="text" class="form-control" id="tgl" data-date-format="yyyy" name="tgl" placeholder="Tahun" required>
                </div>
               
          
</div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
