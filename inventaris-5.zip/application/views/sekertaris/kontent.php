<div class="box box-primary">
          
          <div class="box-body">
            <div class="row">
        <div class="col-md-6">
          <!-- Box Comment -->
          <div class="box box-widget">
           
            <!-- /.box-header -->
            <div class="box-body">
              <img class="img-responsive pad" src="<?php echo base_url()?>assets/images/logo.jpg" >

            </div>
            <!-- /.box-body -->
            
            <!-- /.box-footer -->
            <div class="box-footer">
             
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-6">
          <!-- Box Comment -->
          <div class="box box-widget">
            <div class="box-header with-border">
              <div class="user-block">
        <img class="img-circle" src="<?php echo base_url()?>assets/images/logo.jpg" alt="User Image">
                <span class="username"><a href="#">PT Demo PERSADA MANDIRI</a></span>
                <span class="description">Tentang</span>
              </div>
              <!-- /.user-block -->
              
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <!-- post text -->
              <p><b>Tentang</b> <p></p>Diawali dengan berdirinya CV Demo Persada pada tanggal 16 Mei 2010 dan mengalami perubahan menjadi PT. Demo Persada Mandiri pada tanggal 17 Januari 2014.
PT. Demo Persada Mandiri bergerak dibidang jasa pengadaan, event organizir, advertising dan telah memiliki pengalaman dibidangnya.
</p>
<br />
<p><strong>Visi</strong> <p></p>
Menjadi perusahaan yang unggul dan berkomitmen, serta selalu memberikan layanan terbaik dan terpercaya</p>
<br />
             <p><strong>Misi
</strong><p></p>Menyediakan layanan produk jasa yang berkualitas tinggi dengan harga yang kompetitif berkomitmen untuk berperilaku transparan dan terpercaya kepada seluruh klien dan pemangku kepentingan</p>
            </div>
     
     </div>
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
