            <section class="content-header">
     
        
        <small>  <a href="<?php echo base_url()?>index.php/sekertaris/inventaris/tambah/0" class="btn btn-primary" ><i class="fa fa-plus" ></i> REQUEST</a></small>
           <small>  <a href="<?php echo base_url()?>index.php/sekertaris/inventaris/tambah_k/0" class="btn btn-danger" ><i class="fa fa-plus" ></i> REQUEST PENGEMBALIAN</a></small>
        
     
     
      
    </section>